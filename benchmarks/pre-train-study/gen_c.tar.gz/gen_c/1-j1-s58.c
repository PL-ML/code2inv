int main()
{
  int x;
  int y;
  int junk_0 = 8;
  //skip 
  x = 1;
  
  y = 0;
  
  while(((y) < (100000)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = 49 + (junk_0);
    y = ((y) + (1));
    junk_0 = junk_0;
  }
    //fb 
  assert ((x) >= (y));
  //skip 


}
