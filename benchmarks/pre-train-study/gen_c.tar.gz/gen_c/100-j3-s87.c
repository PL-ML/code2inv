int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 5;
  int junk_1 = 6;
  int junk_2 = 8;
  //skip 
  assume ((n) >= (0));
  x = n;
  
  y = 0;
  
  while(((x) > (0)))
  {
    //tb 
    y = ((y) + (1));
    junk_2 = 333 + (637);
    x = ((x) - (1));
    junk_1 = junk_1;
  }
    //fb 
  assert ((y) == (n));
  //skip 


}
