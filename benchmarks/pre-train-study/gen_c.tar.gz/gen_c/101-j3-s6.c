int main()
{
  int n;
  int x;
  int junk_0 = 6;
  int junk_1 = 4;
  int junk_2 = 1;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_2 = junk_1 + (junk_2);
  }
    //fb 
  if(((x) != (n))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
