int main()
{
  int n;
  int x;
  int junk_0 = 1;
  int junk_1 = 6;
  int junk_2 = 8;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_2 = 210 - (junk_0);
  }
    //fb 
  if(((x) != (n))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
