int main()
{
  int n;
  int x;
  int junk_0 = 7;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = 569 - (junk_0);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
