int main()
{
  int n;
  int x;
  int junk_0 = 2;
  int junk_1 = 1;
  int junk_2 = 9;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_2 = junk_0 - (junk_2);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
