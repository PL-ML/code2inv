int main()
{
  int x;
  int junk_0 = 2;
  //skip 
  x = 0;
  
  while(((x) < (100)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = 520;
  }
    //fb 
  assert ((x) == (100));
  //skip 


}
