int main()
{
  int n;
  int x;
  int junk_0 = 1;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = junk_0 - (junk_0);
  }
    //fb 
  if(((x) != (n))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
