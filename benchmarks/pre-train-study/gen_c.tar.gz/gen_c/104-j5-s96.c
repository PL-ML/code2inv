int main()
{
  int n;
  int x;
  int junk_0 = 2;
  int junk_1 = 2;
  int junk_2 = 6;
  int junk_3 = 2;
  int junk_4 = 6;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_3 = 972 + (559);
  }
    //fb 
  if(((x) != (n))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
