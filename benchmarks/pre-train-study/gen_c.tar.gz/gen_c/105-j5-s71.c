int main()
{
  int n;
  int x;
  int junk_0 = 7;
  int junk_1 = 6;
  int junk_2 = 5;
  int junk_3 = 2;
  int junk_4 = 0;
  //skip 
  x = 0;
  
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_2 = 578;
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
