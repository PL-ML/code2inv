int main()
{
  int a;
  int j;
  int k;
  int m;
  int junk_0 = 6;
  //skip 
  assume ((a) <= (m));
  assume ((j) < (1));
  k = 0;
  
  while(((k) < (1)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_0 = 445 + (598);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 817;
  }
    //fb 
  assert ((a) >= (m));
  //skip 


}
