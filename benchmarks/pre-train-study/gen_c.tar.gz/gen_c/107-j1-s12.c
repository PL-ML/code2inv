int main()
{
  int a;
  int j;
  int k;
  int m;
  int junk_0 = 5;
  //skip 
  j = 0;
  
  k = 0;
  
  while(((k) < (1)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_0 = 505 - (junk_0);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 668;
  }
    //fb 
  assert ((a) <= (m));
  //skip 


}
