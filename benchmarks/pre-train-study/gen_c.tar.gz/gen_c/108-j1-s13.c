int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 1;
  //skip 
  assume ((a) <= (m));
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_0 = 322;
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 872;
  }
    //fb 
  assert ((a) <= (m));
  //skip 


}
