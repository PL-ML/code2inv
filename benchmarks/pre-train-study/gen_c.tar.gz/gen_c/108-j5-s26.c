int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 8;
  int junk_1 = 4;
  int junk_2 = 1;
  int junk_3 = 6;
  int junk_4 = 8;
  //skip 
  assume ((a) <= (m));
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_3 = junk_2 + (230);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 636 + (284);
  }
    //fb 
  assert ((a) <= (m));
  //skip 


}
