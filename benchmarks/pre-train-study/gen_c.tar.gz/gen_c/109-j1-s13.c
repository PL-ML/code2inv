int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 3;
  //skip 
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_0 = 343 - (120);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 299 + (171);
  }
    //fb 
  if(((c) > (0))) {
    //tb 
    assert ((a) <= (m));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
