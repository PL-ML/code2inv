int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 9;
  //skip 
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_0 = 218 - (952);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = 28;
  }
    //fb 
  if(((c) > (0))) {
    //tb 
    assert ((a) <= (m));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
