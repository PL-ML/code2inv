int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 2;
  int junk_1 = 6;
  int junk_2 = 8;
  //skip 
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_1 = junk_0 - (70);
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_2 = 930;
  }
    //fb 
  if(((c) > (0))) {
    //tb 
    assert ((a) <= (m));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
