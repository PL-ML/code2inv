int main()
{
  int a;
  int c;
  int j;
  int k;
  int m;
  int junk_0 = 3;
  int junk_1 = 5;
  int junk_2 = 0;
  int junk_3 = 7;
  int junk_4 = 7;
  //skip 
  j = 0;
  
  k = 0;
  
  while(((k) < (c)))
  {
    //tb 
    if(((m) < (a))) {
      //tb 
      m = a;
      junk_1 = 581;
    }
    else{
      //fb 
    }
    //phi 
    k = ((k) + (1));
    junk_0 = junk_1;
  }
    //fb 
  if(((c) > (0))) {
    //tb 
    assert ((a) <= (m));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
