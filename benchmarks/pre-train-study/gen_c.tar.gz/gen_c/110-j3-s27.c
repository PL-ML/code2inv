int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 8;
  int junk_1 = 1;
  int junk_2 = 3;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = 534 - (229);
    sn = ((sn) + (1));
    junk_2 = junk_2 + (89);
  }
    //fb 
  if(((sn) != (n))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
