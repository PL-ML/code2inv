int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 5;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0 - (junk_0);
    sn = ((sn) + (1));
    junk_0 = junk_0;
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
