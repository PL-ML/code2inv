int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 2;
  int junk_1 = 1;
  int junk_2 = 5;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_1 = junk_1 - (junk_2);
    sn = ((sn) + (1));
    junk_2 = 620 + (683);
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
