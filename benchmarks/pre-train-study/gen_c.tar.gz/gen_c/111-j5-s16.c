int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 5;
  int junk_1 = 4;
  int junk_2 = 1;
  int junk_3 = 9;
  int junk_4 = 4;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_4 = 264 + (junk_4);
    sn = ((sn) + (1));
    junk_4 = 144;
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
