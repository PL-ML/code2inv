int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 5;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = 63 + (432);
    sn = ((sn) + (1));
    junk_0 = 755 + (591);
  }
    //fb 
  if(((sn) != (n))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
