int main()
{
  int i;
  int n;
  int sn;
  int junk_0 = 1;
  int junk_1 = 3;
  int junk_2 = 0;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (n)))
  {
    //tb 
    i = ((i) + (1));
    junk_1 = junk_0 + (junk_1);
    sn = ((sn) + (1));
    junk_0 = 272;
  }
    //fb 
  if(((sn) != (n))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
