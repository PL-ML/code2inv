int main()
{
  int sn;
  int tmp;
  int x;
  int junk_0 = 8;
  //skip 
  sn = 0;
  
  x = 0;
  
  while(unknown())
  {
    //tb 
    x = ((x) + (1));
    junk_0 = 250 + (156);
    sn = ((sn) + (1));
    junk_0 = 845 - (489);
  }
    //fb 
  if(((sn) != (-1))) {
    //tb 
    assert ((sn) == (x));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
