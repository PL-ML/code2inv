int main()
{
  int sn;
  int tmp;
  int x;
  int junk_0 = 2;
  //skip 
  sn = 0;
  
  x = 0;
  
  while(unknown())
  {
    //tb 
    x = ((x) + (1));
    junk_0 = 139;
    sn = ((sn) + (1));
    junk_0 = junk_0;
  }
    //fb 
  if(((sn) != (x))) {
    //tb 
    assert ((sn) == (-1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
