int main()
{
  int sn;
  int tmp;
  int x;
  int junk_0 = 7;
  int junk_1 = 9;
  int junk_2 = 6;
  int junk_3 = 4;
  int junk_4 = 4;
  //skip 
  sn = 0;
  
  x = 0;
  
  while(unknown())
  {
    //tb 
    x = ((x) + (1));
    junk_1 = 106;
    sn = ((sn) + (1));
    junk_0 = 146 + (318);
  }
    //fb 
  if(((sn) != (x))) {
    //tb 
    assert ((sn) == (-1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
