int main()
{
  int sn;
  int tmp;
  int x;
  int junk_0 = 3;
  int junk_1 = 7;
  int junk_2 = 2;
  int junk_3 = 1;
  int junk_4 = 4;
  //skip 
  sn = 0;
  
  x = 0;
  
  while(unknown())
  {
    //tb 
    x = ((x) + (1));
    junk_4 = 338 + (679);
    sn = ((sn) + (1));
    junk_1 = junk_4 + (junk_1);
  }
    //fb 
  if(((sn) != (-1))) {
    //tb 
    assert ((sn) == (x));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
