int main()
{
  int i;
  int size;
  int sn;
  int junk_0 = 4;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (size)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0;
    sn = ((sn) + (1));
    junk_0 = junk_0 - (170);
  }
    //fb 
  if(((sn) != (size))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
