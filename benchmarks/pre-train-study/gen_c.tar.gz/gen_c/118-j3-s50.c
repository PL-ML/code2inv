int main()
{
  int i;
  int size;
  int sn;
  int junk_0 = 2;
  int junk_1 = 5;
  int junk_2 = 9;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (size)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0;
    sn = ((sn) + (1));
    junk_1 = 512;
  }
    //fb 
  if(((sn) != (size))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
