int main()
{
  int i;
  int sn;
  int junk_0 = 7;
  int junk_1 = 7;
  int junk_2 = 1;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (8)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0 + (480);
    sn = ((sn) + (1));
    junk_0 = junk_0 + (435);
  }
    //fb 
  if(((sn) != (8))) {
    //tb 
    assert ((sn) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
