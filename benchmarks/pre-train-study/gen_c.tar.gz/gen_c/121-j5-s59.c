int main()
{
  int i;
  int sn;
  int junk_0 = 9;
  int junk_1 = 1;
  int junk_2 = 0;
  int junk_3 = 2;
  int junk_4 = 0;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (8)))
  {
    //tb 
    i = ((i) + (1));
    junk_3 = 640;
    sn = ((sn) + (1));
    junk_2 = 951 - (junk_2);
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (8));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
