int main()
{
  int i;
  int size;
  int sn;
  int junk_0 = 1;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (size)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = 283;
    sn = ((sn) + (1));
    junk_0 = 521;
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (size));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
