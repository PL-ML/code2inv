int main()
{
  int i;
  int size;
  int sn;
  int junk_0 = 3;
  int junk_1 = 5;
  int junk_2 = 0;
  int junk_3 = 1;
  int junk_4 = 8;
  //skip 
  sn = 0;
  
  i = 1;
  
  while(((i) <= (size)))
  {
    //tb 
    i = ((i) + (1));
    junk_1 = 652;
    sn = ((sn) + (1));
    junk_0 = junk_0 + (junk_1);
  }
    //fb 
  if(((sn) != (0))) {
    //tb 
    assert ((sn) == (size));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
