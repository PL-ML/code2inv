int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 0;
  int junk_1 = 4;
  int junk_2 = 1;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = 789 + (760);
    y = ((y) - (1));
    junk_1 = 835 - (junk_1);
  }
    //fb 
  if(((i) == (j))) {
    //tb 
    assert ((y) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
