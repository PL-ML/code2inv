int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 5;
  int junk_2 = 6;
  int junk_3 = 4;
  int junk_4 = 2;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_4 = junk_4;
    y = ((y) - (1));
    junk_0 = 244 + (junk_4);
  }
    //fb 
  if(((i) == (j))) {
    //tb 
    assert ((y) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
