int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 2;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = junk_0 - (923);
    y = ((y) - (1));
    junk_0 = junk_0 - (junk_0);
  }
    //fb 
  if(((y) != (0))) {
    //tb 
    assert ((i) != (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
