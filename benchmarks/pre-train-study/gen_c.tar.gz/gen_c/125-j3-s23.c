int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 2;
  int junk_2 = 6;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 131;
    y = ((y) - (1));
    junk_1 = 157 + (junk_0);
  }
    //fb 
  if(((y) != (0))) {
    //tb 
    assert ((i) != (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
