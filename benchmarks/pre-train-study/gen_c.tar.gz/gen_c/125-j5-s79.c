int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 4;
  int junk_1 = 9;
  int junk_2 = 4;
  int junk_3 = 1;
  int junk_4 = 8;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 918;
    y = ((y) - (1));
    junk_3 = junk_3;
  }
    //fb 
  if(((y) != (0))) {
    //tb 
    assert ((i) != (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
