int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 5;
  int junk_1 = 5;
  int junk_2 = 4;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = junk_0;
    y = ((y) - (1));
    junk_2 = junk_2 + (300);
  }
    //fb 
  if(((y) != (0))) {
    //tb 
    assert ((i) != (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
