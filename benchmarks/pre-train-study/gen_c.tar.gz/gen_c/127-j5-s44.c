int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 8;
  int junk_1 = 2;
  int junk_2 = 6;
  int junk_3 = 0;
  int junk_4 = 0;
  //skip 
  i = x;
  
  j = y;
  
  while(((x) != (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_3 = 663 - (643);
    y = ((y) - (1));
    junk_4 = junk_1;
  }
    //fb 
  if(((y) != (0))) {
    //tb 
    assert ((i) != (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
