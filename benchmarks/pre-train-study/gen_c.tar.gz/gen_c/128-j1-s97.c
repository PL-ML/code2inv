int main()
{
  int x;
  int y;
  int junk_0 = 4;
  //skip 
  x = 1;
  
  while(((x) < (y)))
  {
    //tb 
    x = ((x) + (x));
    junk_0 = junk_0 - (junk_0);
  }
    //fb 
  assert ((x) >= (1));
  //skip 


}
