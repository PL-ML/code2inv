int main()
{
  int x;
  int y;
  int junk_0 = 1;
  int junk_1 = 1;
  int junk_2 = 6;
  int junk_3 = 2;
  int junk_4 = 0;
  //skip 
  x = 1;
  
  while(((x) < (y)))
  {
    //tb 
    x = ((x) + (x));
    junk_4 = 673;
  }
    //fb 
  assert ((x) >= (1));
  //skip 


}
