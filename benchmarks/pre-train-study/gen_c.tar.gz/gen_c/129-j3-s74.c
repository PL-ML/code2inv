int main()
{
  int x;
  int y;
  int junk_0 = 1;
  int junk_1 = 1;
  int junk_2 = 1;
  //skip 
  x = 1;
  
  while(((x) < (y)))
  {
    //tb 
    x = ((x) + (x));
    junk_2 = 45;
  }
    //fb 
  assert ((x) >= (1));
  //skip 


}
