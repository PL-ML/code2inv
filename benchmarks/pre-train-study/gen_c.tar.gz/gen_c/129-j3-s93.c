int main()
{
  int x;
  int y;
  int junk_0 = 7;
  int junk_1 = 7;
  int junk_2 = 5;
  //skip 
  x = 1;
  
  while(((x) < (y)))
  {
    //tb 
    x = ((x) + (x));
    junk_2 = 12;
  }
    //fb 
  assert ((x) >= (1));
  //skip 


}
