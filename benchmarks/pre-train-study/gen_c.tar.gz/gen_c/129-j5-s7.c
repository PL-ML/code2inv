int main()
{
  int x;
  int y;
  int junk_0 = 4;
  int junk_1 = 1;
  int junk_2 = 1;
  int junk_3 = 2;
  int junk_4 = 5;
  //skip 
  x = 1;
  
  while(((x) < (y)))
  {
    //tb 
    x = ((x) + (x));
    junk_4 = 165;
  }
    //fb 
  assert ((x) >= (1));
  //skip 


}
