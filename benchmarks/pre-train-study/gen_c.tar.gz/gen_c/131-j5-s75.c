int main()
{
  int d1;
  int d2;
  int d3;
  int x1;
  int x2;
  int x3;
  int junk_0 = 6;
  int junk_1 = 2;
  int junk_2 = 3;
  int junk_3 = 2;
  int junk_4 = 8;
  //skip 
  d1 = 1;
  
  d2 = 1;
  
  d3 = 1;
  
  x1 = 1;
  
  while(((x1) > (0)))
  {
    //tb 
    if(((x2) > (0))) {
      //tb 
      if(((x3) > (0))) {
        //tb 
        x1 = ((x1) - (d1));
        junk_4 = 238 + (588);
        x2 = ((x2) - (d2));
        junk_0 = junk_2;
        x3 = ((x3) - (d3));
        junk_2 = junk_2;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((x3) >= (0));
  //skip 


}
