int main()
{
  int c;
  int i;
  int j;
  int t;
  int tmp;
  int junk_0 = 3;
  //skip 
  i = 0;
  
  while(unknown())
  {
    //tb 
    if(((c) > (48))) {
      //tb 
      if(((c) < (57))) {
        //tb 
        j = ((i) + (i));
        junk_0 = 284;
        t = ((c) - (48));
        junk_0 = junk_0;
        i = ((j) + (t));
        junk_0 = junk_0 + (junk_0);
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((i) >= (0));
  //skip 


}
