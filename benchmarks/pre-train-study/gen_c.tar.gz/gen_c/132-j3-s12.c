int main()
{
  int c;
  int i;
  int j;
  int t;
  int tmp;
  int junk_0 = 3;
  int junk_1 = 9;
  int junk_2 = 0;
  //skip 
  i = 0;
  
  while(unknown())
  {
    //tb 
    if(((c) > (48))) {
      //tb 
      if(((c) < (57))) {
        //tb 
        j = ((i) + (i));
        junk_0 = 557;
        t = ((c) - (48));
        junk_2 = junk_2 + (junk_0);
        i = ((j) + (t));
        junk_2 = junk_1 - (junk_0);
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((i) >= (0));
  //skip 


}
