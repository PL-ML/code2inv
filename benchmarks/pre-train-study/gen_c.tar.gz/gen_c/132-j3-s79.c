int main()
{
  int c;
  int i;
  int j;
  int t;
  int tmp;
  int junk_0 = 6;
  int junk_1 = 9;
  int junk_2 = 1;
  //skip 
  i = 0;
  
  while(unknown())
  {
    //tb 
    if(((c) > (48))) {
      //tb 
      if(((c) < (57))) {
        //tb 
        j = ((i) + (i));
        junk_2 = junk_1;
        t = ((c) - (48));
        junk_1 = 610;
        i = ((j) + (t));
        junk_1 = 37;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((i) >= (0));
  //skip 


}
