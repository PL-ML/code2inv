int main()
{
  int c;
  int i;
  int j;
  int t;
  int tmp;
  int junk_0 = 9;
  int junk_1 = 8;
  int junk_2 = 1;
  int junk_3 = 5;
  int junk_4 = 8;
  //skip 
  i = 0;
  
  while(unknown())
  {
    //tb 
    if(((c) > (48))) {
      //tb 
      if(((c) < (57))) {
        //tb 
        j = ((i) + (i));
        junk_4 = 675 + (junk_3);
        t = ((c) - (48));
        junk_1 = junk_1;
        i = ((j) + (t));
        junk_0 = 246;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((i) >= (0));
  //skip 


}
