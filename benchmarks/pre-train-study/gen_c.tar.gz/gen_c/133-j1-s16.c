int main()
{
  int n;
  int x;
  int junk_0 = 9;
  //skip 
  x = 0;
  
  assume ((n) >= (0));
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = junk_0 + (496);
  }
    //fb 
  assert ((x) == (n));
  //skip 


}
