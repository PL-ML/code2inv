int main()
{
  int n;
  int x;
  int junk_0 = 9;
  int junk_1 = 3;
  int junk_2 = 6;
  int junk_3 = 6;
  int junk_4 = 3;
  //skip 
  x = 0;
  
  assume ((n) >= (0));
  while(((x) < (n)))
  {
    //tb 
    x = ((x) + (1));
    junk_3 = 273 + (897);
  }
    //fb 
  assert ((x) == (n));
  //skip 


}
