int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 9;
  int junk_1 = 3;
  int junk_2 = 0;
  int junk_3 = 4;
  int junk_4 = 9;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_2 = 110;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = junk_3;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
