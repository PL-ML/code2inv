int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 8;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_0 = junk_0;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = junk_0 + (junk_0);
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
