int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 1;
  int junk_1 = 4;
  int junk_2 = 8;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_1 = junk_2 - (334);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_1 = 769;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
