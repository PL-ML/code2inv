int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 6;
  int junk_1 = 4;
  int junk_2 = 2;
  int junk_3 = 3;
  int junk_4 = 7;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_4 = 769 - (131);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_3 = junk_2;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
