int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 6;
  int junk_1 = 5;
  int junk_2 = 9;
  int junk_3 = 4;
  int junk_4 = 8;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_3 = 141 + (138);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = 689;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
