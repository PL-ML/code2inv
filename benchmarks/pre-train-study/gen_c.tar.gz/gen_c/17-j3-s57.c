int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 2;
  int junk_1 = 3;
  int junk_2 = 8;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_1 = 794 - (junk_1);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = 974;
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
