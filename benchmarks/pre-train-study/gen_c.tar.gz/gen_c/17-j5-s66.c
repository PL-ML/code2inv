int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 7;
  int junk_1 = 8;
  int junk_2 = 3;
  int junk_3 = 7;
  int junk_4 = 2;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_2 = 267;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_3 = junk_2;
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
