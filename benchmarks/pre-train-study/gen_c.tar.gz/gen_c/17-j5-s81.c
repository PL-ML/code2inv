int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 9;
  int junk_1 = 6;
  int junk_2 = 1;
  int junk_3 = 9;
  int junk_4 = 7;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_2 = 932 - (200);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = junk_2 - (554);
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
