int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 9;
  int junk_1 = 1;
  int junk_2 = 5;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_1 = 984;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = 38 + (junk_1);
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) >= (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
