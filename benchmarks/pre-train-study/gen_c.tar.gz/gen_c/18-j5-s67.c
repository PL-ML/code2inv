int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 7;
  int junk_1 = 5;
  int junk_2 = 9;
  int junk_3 = 3;
  int junk_4 = 4;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_4 = junk_2;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_4 = 657 + (junk_1);
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) >= (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
