int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 9;
  int junk_1 = 4;
  int junk_2 = 2;
  int junk_3 = 2;
  int junk_4 = 3;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_0 = junk_2;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_4 = junk_1;
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) >= (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
