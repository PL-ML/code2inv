int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 7;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_0 = 561 + (26);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = 533;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
