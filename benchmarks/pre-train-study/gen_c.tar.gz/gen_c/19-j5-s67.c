int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 8;
  int junk_1 = 9;
  int junk_2 = 8;
  int junk_3 = 0;
  int junk_4 = 7;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_2 = junk_2;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = junk_1 - (214);
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
