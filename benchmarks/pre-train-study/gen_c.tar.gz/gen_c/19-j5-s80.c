int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 4;
  int junk_1 = 5;
  int junk_2 = 4;
  int junk_3 = 3;
  int junk_4 = 0;
  //skip 
  x = 0;
  
  m = 0;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_3 = 495 + (junk_3);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_1 = 603 + (180);
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
