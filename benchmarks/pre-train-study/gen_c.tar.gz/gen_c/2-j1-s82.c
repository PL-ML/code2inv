int main()
{
  int x;
  int y;
  int junk_0 = 4;
  //skip 
  x = 1;
  
  y = 0;
  
  while(((y) < (1000)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = 382;
    y = ((y) + (1));
    junk_0 = 594 - (junk_0);
  }
    //fb 
  assert ((x) >= (y));
  //skip 


}
