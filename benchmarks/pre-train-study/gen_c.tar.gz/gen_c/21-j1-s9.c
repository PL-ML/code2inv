int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 9;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_0 = 158 + (junk_0);
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_0 = 991;
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
