int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 2;
  int junk_1 = 1;
  int junk_2 = 9;
  int junk_3 = 3;
  int junk_4 = 3;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_1 = junk_1;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_3 = junk_3 + (803);
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) >= (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
