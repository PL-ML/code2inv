int main()
{
  int m;
  int n;
  int tmp;
  int x;
  int junk_0 = 4;
  int junk_1 = 3;
  int junk_2 = 0;
  int junk_3 = 8;
  int junk_4 = 5;
  //skip 
  x = 1;
  
  m = 1;
  
  while(((x) < (n)))
  {
    //tb 
    if(unknown()) {
      //tb 
      m = x;
      junk_3 = junk_2;
    }
    else{
      //fb 
    }
    //phi 
    x = ((x) + (1));
    junk_2 = 137;
  }
    //fb 
  if(((n) > (1))) {
    //tb 
    assert ((m) >= (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
