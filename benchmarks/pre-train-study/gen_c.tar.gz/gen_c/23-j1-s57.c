int main()
{
  int i;
  int j;
  int junk_0 = 2;
  //skip 
  i = 1;
  
  j = 20;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_0 = 388 - (junk_0);
    j = ((j) - (1));
    junk_0 = junk_0 - (754);
  }
    //fb 
  assert ((j) == (13));
  //skip 


}
