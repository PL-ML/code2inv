int main()
{
  int i;
  int j;
  int junk_0 = 7;
  int junk_1 = 9;
  int junk_2 = 5;
  //skip 
  i = 1;
  
  j = 20;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_0 = 525 - (801);
    j = ((j) - (1));
    junk_2 = 71;
  }
    //fb 
  assert ((j) == (13));
  //skip 


}
