int main()
{
  int i;
  int j;
  int junk_0 = 3;
  int junk_1 = 2;
  int junk_2 = 4;
  //skip 
  i = 1;
  
  j = 20;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_2 = 392 - (junk_0);
    j = ((j) - (1));
    junk_1 = 89 + (953);
  }
    //fb 
  assert ((j) == (13));
  //skip 


}
