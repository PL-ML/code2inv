int main()
{
  int i;
  int j;
  int junk_0 = 9;
  int junk_1 = 5;
  int junk_2 = 5;
  int junk_3 = 7;
  int junk_4 = 2;
  //skip 
  i = 1;
  
  j = 20;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_1 = 454 - (junk_1);
    j = ((j) - (1));
    junk_0 = junk_1 - (junk_1);
  }
    //fb 
  assert ((j) == (13));
  //skip 


}
