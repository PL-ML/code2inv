int main()
{
  int i;
  int j;
  int junk_0 = 1;
  int junk_1 = 4;
  int junk_2 = 9;
  int junk_3 = 5;
  int junk_4 = 7;
  //skip 
  i = 1;
  
  j = 20;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_1 = junk_2;
    j = ((j) - (1));
    junk_0 = junk_1 - (junk_0);
  }
    //fb 
  assert ((j) == (13));
  //skip 


}
