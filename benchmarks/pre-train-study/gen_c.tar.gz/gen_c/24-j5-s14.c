int main()
{
  int i;
  int j;
  int junk_0 = 5;
  int junk_1 = 8;
  int junk_2 = 9;
  int junk_3 = 9;
  int junk_4 = 7;
  //skip 
  i = 1;
  
  j = 10;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_2 = 490 + (934);
    j = ((j) - (1));
    junk_1 = junk_3;
  }
    //fb 
  assert ((j) == (6));
  //skip 


}
