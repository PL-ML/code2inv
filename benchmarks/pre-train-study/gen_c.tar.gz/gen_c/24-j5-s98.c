int main()
{
  int i;
  int j;
  int junk_0 = 7;
  int junk_1 = 7;
  int junk_2 = 2;
  int junk_3 = 2;
  int junk_4 = 9;
  //skip 
  i = 1;
  
  j = 10;
  
  while(((j) >= (i)))
  {
    //tb 
    i = ((i) + (2));
    junk_4 = 338 - (junk_4);
    j = ((j) - (1));
    junk_2 = junk_0 + (22);
  }
    //fb 
  assert ((j) == (6));
  //skip 


}
