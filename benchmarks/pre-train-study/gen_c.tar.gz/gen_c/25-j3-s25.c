int main()
{
  int x;
  int junk_0 = 3;
  int junk_1 = 5;
  int junk_2 = 5;
  //skip 
  x = 10000;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 58 - (junk_0);
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
