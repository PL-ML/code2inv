int main()
{
  int x;
  int junk_0 = 0;
  int junk_1 = 9;
  int junk_2 = 4;
  //skip 
  x = 10000;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = 149;
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
