int main()
{
  int n;
  int x;
  int junk_0 = 0;
  int junk_1 = 6;
  int junk_2 = 0;
  int junk_3 = 4;
  int junk_4 = 3;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = junk_0;
  }
    //fb 
  if(((x) != (1))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
