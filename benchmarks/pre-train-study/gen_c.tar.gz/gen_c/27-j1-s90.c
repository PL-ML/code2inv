int main()
{
  int n;
  int x;
  int junk_0 = 5;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 921 - (junk_0);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
