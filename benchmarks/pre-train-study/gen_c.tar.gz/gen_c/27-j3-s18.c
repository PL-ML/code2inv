int main()
{
  int n;
  int x;
  int junk_0 = 7;
  int junk_1 = 5;
  int junk_2 = 6;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 188;
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
