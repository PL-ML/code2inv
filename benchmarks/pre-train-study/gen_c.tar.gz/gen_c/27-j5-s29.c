int main()
{
  int n;
  int x;
  int junk_0 = 5;
  int junk_1 = 8;
  int junk_2 = 3;
  int junk_3 = 7;
  int junk_4 = 0;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 236;
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
