int main()
{
  int n;
  int x;
  int junk_0 = 8;
  int junk_1 = 8;
  int junk_2 = 9;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = junk_2 + (junk_0);
  }
    //fb 
  if(((x) != (0))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
