int main()
{
  int n;
  int x;
  int junk_0 = 0;
  int junk_1 = 2;
  int junk_2 = 2;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = junk_1;
  }
    //fb 
  if(((x) != (0))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
