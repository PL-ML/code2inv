int main()
{
  int n;
  int x;
  int junk_0 = 6;
  int junk_1 = 0;
  int junk_2 = 8;
  int junk_3 = 1;
  int junk_4 = 3;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 894;
  }
    //fb 
  if(((x) != (0))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
