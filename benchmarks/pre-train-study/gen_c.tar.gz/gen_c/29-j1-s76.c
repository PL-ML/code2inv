int main()
{
  int n;
  int x;
  int junk_0 = 5;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = junk_0;
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
