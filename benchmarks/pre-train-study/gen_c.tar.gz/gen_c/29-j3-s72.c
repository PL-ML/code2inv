int main()
{
  int n;
  int x;
  int junk_0 = 9;
  int junk_1 = 3;
  int junk_2 = 1;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = junk_0 - (junk_1);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
