int main()
{
  int n;
  int x;
  int junk_0 = 0;
  int junk_1 = 6;
  int junk_2 = 4;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 924 - (junk_1);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
