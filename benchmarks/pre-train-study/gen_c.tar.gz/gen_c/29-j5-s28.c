int main()
{
  int n;
  int x;
  int junk_0 = 5;
  int junk_1 = 8;
  int junk_2 = 7;
  int junk_3 = 9;
  int junk_4 = 3;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = junk_4 + (junk_1);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
