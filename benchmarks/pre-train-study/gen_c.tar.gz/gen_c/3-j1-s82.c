int main()
{
  int x;
  int y;
  int z;
  int junk_0 = 2;
  //skip 
  x = 0;
  
  while(((x) < (5)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = 234;
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_0 = 40;
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((z) >= (y));
  //skip 


}
