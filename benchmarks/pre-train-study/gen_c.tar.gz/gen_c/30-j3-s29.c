int main()
{
  int x;
  int junk_0 = 6;
  int junk_1 = 4;
  int junk_2 = 6;
  //skip 
  x = 100;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = 759 + (junk_1);
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
