int main()
{
  int x;
  int junk_0 = 3;
  int junk_1 = 9;
  int junk_2 = 0;
  int junk_3 = 4;
  int junk_4 = 7;
  //skip 
  x = 100;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 402;
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
