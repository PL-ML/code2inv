int main()
{
  int x;
  int junk_0 = 1;
  int junk_1 = 8;
  int junk_2 = 4;
  int junk_3 = 7;
  int junk_4 = 1;
  //skip 
  x = 100;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 834;
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
