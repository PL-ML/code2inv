int main()
{
  int x;
  int junk_0 = 0;
  int junk_1 = 6;
  int junk_2 = 2;
  int junk_3 = 8;
  int junk_4 = 5;
  //skip 
  x = 100;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = 217;
  }
    //fb 
  assert ((x) == (0));
  //skip 


}
