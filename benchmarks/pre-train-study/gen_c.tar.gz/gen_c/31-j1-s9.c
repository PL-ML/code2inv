int main()
{
  int n;
  int x;
  int junk_0 = 5;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_0 = junk_0;
  }
    //fb 
  if(((x) != (1))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
