int main()
{
  int n;
  int x;
  int junk_0 = 1;
  int junk_1 = 8;
  int junk_2 = 5;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = junk_0;
  }
    //fb 
  if(((x) != (1))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
