int main()
{
  int n;
  int x;
  int junk_0 = 0;
  int junk_1 = 6;
  int junk_2 = 2;
  int junk_3 = 7;
  int junk_4 = 9;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 725;
  }
    //fb 
  if(((x) != (1))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
