int main()
{
  int n;
  int x;
  int junk_0 = 8;
  int junk_1 = 9;
  int junk_2 = 7;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 694 - (310);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
