int main()
{
  int n;
  int x;
  int junk_0 = 4;
  int junk_1 = 2;
  int junk_2 = 4;
  int junk_3 = 9;
  int junk_4 = 3;
  //skip 
  x = n;
  
  while(((x) > (1)))
  {
    //tb 
    x = ((x) - (1));
    junk_3 = junk_3 - (junk_4);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
