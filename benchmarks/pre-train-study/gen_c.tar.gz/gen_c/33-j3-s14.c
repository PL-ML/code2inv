int main()
{
  int n;
  int x;
  int junk_0 = 8;
  int junk_1 = 5;
  int junk_2 = 5;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = 637;
  }
    //fb 
  if(((x) != (0))) {
    //tb 
    assert ((n) < (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
