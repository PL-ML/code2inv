int main()
{
  int n;
  int x;
  int junk_0 = 4;
  int junk_1 = 6;
  int junk_2 = 6;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_1 = 235 - (junk_2);
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
