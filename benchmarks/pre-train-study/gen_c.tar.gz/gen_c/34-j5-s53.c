int main()
{
  int n;
  int x;
  int junk_0 = 3;
  int junk_1 = 2;
  int junk_2 = 4;
  int junk_3 = 5;
  int junk_4 = 9;
  //skip 
  x = n;
  
  while(((x) > (0)))
  {
    //tb 
    x = ((x) - (1));
    junk_2 = 786;
  }
    //fb 
  if(((n) >= (0))) {
    //tb 
    assert ((x) == (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
