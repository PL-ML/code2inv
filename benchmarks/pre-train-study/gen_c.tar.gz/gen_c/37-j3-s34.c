int main()
{
  int c;
  int tmp;
  int tmp___0;
  int junk_0 = 9;
  int junk_1 = 1;
  int junk_2 = 8;
  //skip 
  c = 0;
  
  while(unknown())
  {
    //tb 
    if(unknown()) {
      //tb 
      if(((c) != (40))) {
        //tb 
        c = ((c) + (1));
        junk_0 = junk_2;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
      if(((c) == (40))) {
        //tb 
        c = 1;
        junk_2 = 410;
      }
      else{
        //fb 
      }
    }
  }
    //fb 
  if(((c) < (0))) {
    //tb 
    if(((c) > (40))) {
      //tb 
      assert ((c) == (40));
    }
    else{
      //fb 
    }
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
