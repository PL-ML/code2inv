int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 7;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_0 = 413 + (junk_0);
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_0 = 109 + (415);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
