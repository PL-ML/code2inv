int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 4;
  int junk_1 = 3;
  int junk_2 = 1;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_0 = 656 + (311);
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_0 = junk_2 - (junk_1);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
