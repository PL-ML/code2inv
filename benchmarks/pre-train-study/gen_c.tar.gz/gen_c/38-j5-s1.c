int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 7;
  int junk_1 = 1;
  int junk_2 = 4;
  int junk_3 = 5;
  int junk_4 = 8;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_2 = junk_3;
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_4 = 947 - (94);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
