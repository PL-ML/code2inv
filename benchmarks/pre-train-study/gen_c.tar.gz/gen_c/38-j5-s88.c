int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 9;
  int junk_1 = 7;
  int junk_2 = 9;
  int junk_3 = 8;
  int junk_4 = 3;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_1 = 259;
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_4 = junk_0 + (737);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
