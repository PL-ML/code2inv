int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 9;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_0 = 493 + (junk_0);
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_0 = 51 - (503);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) <= (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
