int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 8;
  int junk_1 = 8;
  int junk_2 = 6;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_2 = junk_1;
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_1 = 419 + (junk_1);
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) <= (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
