int main()
{
  int c;
  int n;
  int tmp;
  int junk_0 = 5;
  int junk_1 = 3;
  int junk_2 = 6;
  int junk_3 = 2;
  int junk_4 = 3;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(((c) == (n))) {
      //tb 
      c = 1;
      junk_2 = 930 - (junk_1);
    }
    else{
      //fb 
      c = ((c) + (1));
      junk_2 = junk_1;
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((c) <= (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
