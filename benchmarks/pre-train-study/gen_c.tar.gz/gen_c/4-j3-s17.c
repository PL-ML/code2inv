int main()
{
  int x;
  int y;
  int z;
  int junk_0 = 7;
  int junk_1 = 6;
  int junk_2 = 0;
  //skip 
  x = 0;
  
  while(((x) < (500)))
  {
    //tb 
    x = ((x) + (1));
    junk_1 = 193 + (junk_0);
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_1 = 982 - (junk_1);
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((z) >= (y));
  //skip 


}
