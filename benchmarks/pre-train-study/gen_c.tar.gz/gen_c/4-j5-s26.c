int main()
{
  int x;
  int y;
  int z;
  int junk_0 = 3;
  int junk_1 = 8;
  int junk_2 = 7;
  int junk_3 = 4;
  int junk_4 = 1;
  //skip 
  x = 0;
  
  while(((x) < (500)))
  {
    //tb 
    x = ((x) + (1));
    junk_3 = 55;
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_0 = junk_4;
    }
    else{
      //fb 
    }
  }
    //fb 
  assert ((z) >= (y));
  //skip 


}
