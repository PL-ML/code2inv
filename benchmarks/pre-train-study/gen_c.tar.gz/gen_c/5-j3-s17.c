int main()
{
  int size;
  int x;
  int y;
  int z;
  int junk_0 = 9;
  int junk_1 = 2;
  int junk_2 = 6;
  //skip 
  x = 0;
  
  while(((x) < (size)))
  {
    //tb 
    x = ((x) + (1));
    junk_2 = 712;
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_2 = 930;
    }
    else{
      //fb 
    }
  }
    //fb 
  if(((size) > (0))) {
    //tb 
    assert ((z) >= (y));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
