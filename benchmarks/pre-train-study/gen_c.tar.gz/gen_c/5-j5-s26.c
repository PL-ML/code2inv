int main()
{
  int size;
  int x;
  int y;
  int z;
  int junk_0 = 7;
  int junk_1 = 5;
  int junk_2 = 0;
  int junk_3 = 0;
  int junk_4 = 1;
  //skip 
  x = 0;
  
  while(((x) < (size)))
  {
    //tb 
    x = ((x) + (1));
    junk_1 = 264;
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_3 = junk_0;
    }
    else{
      //fb 
    }
  }
    //fb 
  if(((size) > (0))) {
    //tb 
    assert ((z) >= (y));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
