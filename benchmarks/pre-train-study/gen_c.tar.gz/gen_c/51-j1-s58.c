int main()
{
  int c;
  int tmp;
  int tmp___0;
  int junk_0 = 5;
  //skip 
  c = 0;
  
  while(unknown())
  {
    //tb 
    if(unknown()) {
      //tb 
      if(((c) != (4))) {
        //tb 
        c = ((c) + (1));
        junk_0 = junk_0 - (627);
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
      if(((c) == (4))) {
        //tb 
        c = 1;
        junk_0 = 547;
      }
      else{
        //fb 
      }
    }
  }
    //fb 
  if(((c) != (4))) {
    //tb 
    assert ((c) <= (4));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
