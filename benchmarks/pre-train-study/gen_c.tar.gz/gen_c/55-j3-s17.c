int main()
{
  int c;
  int n;
  int tmp;
  int tmp___0;
  int junk_0 = 7;
  int junk_1 = 8;
  int junk_2 = 1;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(unknown()) {
      //tb 
      if(((c) > (n))) {
        //tb 
        c = ((c) + (1));
        junk_1 = 165;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
      if(((c) == (n))) {
        //tb 
        c = 1;
        junk_2 = junk_2 - (20);
      }
      else{
        //fb 
      }
    }
  }
    //fb 
  if(((c) < (0))) {
    //tb 
    if(((c) > (n))) {
      //tb 
      assert ((c) == (n));
    }
    else{
      //fb 
    }
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
