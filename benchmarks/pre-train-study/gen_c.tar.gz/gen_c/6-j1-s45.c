int main()
{
  int size;
  int x;
  int y;
  int z;
  int junk_0 = 3;
  //skip 
  x = 0;
  
  while(((x) < (size)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = junk_0;
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_0 = junk_0;
    }
    else{
      //fb 
    }
  }
    //fb 
  if(((size) > (0))) {
    //tb 
    assert ((z) >= (y));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
