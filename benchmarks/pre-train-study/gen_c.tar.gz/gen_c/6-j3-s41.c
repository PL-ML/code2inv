int main()
{
  int size;
  int x;
  int y;
  int z;
  int junk_0 = 8;
  int junk_1 = 3;
  int junk_2 = 2;
  //skip 
  x = 0;
  
  while(((x) < (size)))
  {
    //tb 
    x = ((x) + (1));
    junk_1 = junk_2 + (junk_0);
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_2 = junk_0;
    }
    else{
      //fb 
    }
  }
    //fb 
  if(((size) > (0))) {
    //tb 
    assert ((z) >= (y));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
