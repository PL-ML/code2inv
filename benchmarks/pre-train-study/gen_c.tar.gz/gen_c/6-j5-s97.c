int main()
{
  int size;
  int x;
  int y;
  int z;
  int junk_0 = 7;
  int junk_1 = 6;
  int junk_2 = 4;
  int junk_3 = 3;
  int junk_4 = 1;
  //skip 
  x = 0;
  
  while(((x) < (size)))
  {
    //tb 
    x = ((x) + (1));
    junk_0 = junk_3 + (208);
    if(((z) <= (y))) {
      //tb 
      y = z;
      junk_3 = 239 - (junk_0);
    }
    else{
      //fb 
    }
  }
    //fb 
  if(((size) > (0))) {
    //tb 
    assert ((z) >= (y));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
