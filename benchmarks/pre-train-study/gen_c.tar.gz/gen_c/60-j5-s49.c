int main()
{
  int c;
  int n;
  int tmp;
  int tmp___0;
  int junk_0 = 3;
  int junk_1 = 8;
  int junk_2 = 4;
  int junk_3 = 6;
  int junk_4 = 8;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(unknown()) {
      //tb 
      if(((c) != (n))) {
        //tb 
        c = ((c) + (1));
        junk_3 = junk_1;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
      if(((c) == (n))) {
        //tb 
        c = 1;
        junk_4 = 815;
      }
      else{
        //fb 
      }
    }
  }
    //fb 
  if(((c) < (0))) {
    //tb 
    if(((c) > (n))) {
      //tb 
      assert ((c) == (n));
    }
    else{
      //fb 
    }
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
