int main()
{
  int c;
  int n;
  int tmp;
  int tmp___0;
  int junk_0 = 4;
  //skip 
  c = 0;
  
  assume ((n) > (0));
  while(unknown())
  {
    //tb 
    if(unknown()) {
      //tb 
      if(((c) != (n))) {
        //tb 
        c = ((c) + (1));
        junk_0 = 620;
      }
      else{
        //fb 
      }
    }
    else{
      //fb 
      if(((c) == (n))) {
        //tb 
        c = 1;
        junk_0 = 278 + (86);
      }
      else{
        //fb 
      }
    }
  }
    //fb 
  if(((c) == (n))) {
    //tb 
    assert ((n) <= (-1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
