int main()
{
  int x;
  int y;
  int junk_0 = 0;
  //skip 
  x = 1;
  
  while(((x) <= (10)))
  {
    //tb 
    y = ((10) - (x));
    junk_0 = 350 + (222);
    x = ((x) + (1));
    junk_0 = 845 - (250);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
