int main()
{
  int x;
  int y;
  int junk_0 = 7;
  int junk_1 = 3;
  int junk_2 = 8;
  //skip 
  x = 1;
  
  while(((x) <= (10)))
  {
    //tb 
    y = ((10) - (x));
    junk_2 = 919;
    x = ((x) + (1));
    junk_1 = 508 - (77);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
