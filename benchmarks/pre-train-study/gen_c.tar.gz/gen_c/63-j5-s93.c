int main()
{
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 9;
  int junk_2 = 0;
  int junk_3 = 2;
  int junk_4 = 6;
  //skip 
  x = 1;
  
  while(((x) <= (10)))
  {
    //tb 
    y = ((10) - (x));
    junk_1 = junk_3 - (419);
    x = ((x) + (1));
    junk_1 = junk_4 + (junk_4);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
