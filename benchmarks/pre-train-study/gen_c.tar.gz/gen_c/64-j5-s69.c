int main()
{
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 5;
  int junk_2 = 7;
  int junk_3 = 7;
  int junk_4 = 4;
  //skip 
  x = 1;
  
  while(((x) <= (10)))
  {
    //tb 
    y = ((10) - (x));
    junk_4 = 746;
    x = ((x) + (1));
    junk_3 = 712 + (484);
  }
    //fb 
  assert ((y) < (10));
  //skip 


}
