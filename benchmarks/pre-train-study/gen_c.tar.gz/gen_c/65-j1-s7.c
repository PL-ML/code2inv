int main()
{
  int x;
  int y;
  int junk_0 = 2;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_0 = 542 - (junk_0);
    x = ((x) + (1));
    junk_0 = junk_0;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
