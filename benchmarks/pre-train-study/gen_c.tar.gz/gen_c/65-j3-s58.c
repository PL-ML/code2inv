int main()
{
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 9;
  int junk_2 = 8;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_2 = 717 + (junk_1);
    x = ((x) + (1));
    junk_1 = junk_0;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
