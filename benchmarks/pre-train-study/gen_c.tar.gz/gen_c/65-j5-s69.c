int main()
{
  int x;
  int y;
  int junk_0 = 7;
  int junk_1 = 7;
  int junk_2 = 0;
  int junk_3 = 8;
  int junk_4 = 3;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_2 = 108 + (508);
    x = ((x) + (1));
    junk_4 = junk_4;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
