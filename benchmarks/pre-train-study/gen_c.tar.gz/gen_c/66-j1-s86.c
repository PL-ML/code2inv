int main()
{
  int x;
  int y;
  int junk_0 = 0;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_0 = 846;
    x = ((x) + (1));
    junk_0 = 25;
  }
    //fb 
  assert ((y) < (100));
  //skip 


}
