int main()
{
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 6;
  int junk_2 = 8;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_1 = 305;
    x = ((x) + (1));
    junk_1 = 157 + (376);
  }
    //fb 
  assert ((y) < (100));
  //skip 


}
