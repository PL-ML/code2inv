int main()
{
  int x;
  int y;
  int junk_0 = 5;
  int junk_1 = 8;
  int junk_2 = 9;
  //skip 
  x = 1;
  
  while(((x) <= (100)))
  {
    //tb 
    y = ((100) - (x));
    junk_2 = 972;
    x = ((x) + (1));
    junk_2 = 667 + (417);
  }
    //fb 
  assert ((y) < (100));
  //skip 


}
