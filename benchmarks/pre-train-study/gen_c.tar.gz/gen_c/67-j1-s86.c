int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 6;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_0 = 776;
    x = ((x) + (1));
    junk_0 = junk_0 - (junk_0);
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
