int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 6;
  int junk_2 = 6;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_2 = 870 - (478);
    x = ((x) + (1));
    junk_1 = 983;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
