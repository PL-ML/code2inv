int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 8;
  int junk_1 = 4;
  int junk_2 = 8;
  int junk_3 = 6;
  int junk_4 = 2;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_4 = 328 - (junk_2);
    x = ((x) + (1));
    junk_3 = junk_3;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
