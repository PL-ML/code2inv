int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 0;
  int junk_2 = 6;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_1 = junk_0;
    x = ((x) + (1));
    junk_1 = 821;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) <= (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
