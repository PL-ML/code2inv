int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 0;
  int junk_2 = 4;
  int junk_3 = 2;
  int junk_4 = 0;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_3 = junk_1 - (511);
    x = ((x) + (1));
    junk_3 = 427;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) <= (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
