int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 0;
  int junk_1 = 2;
  int junk_2 = 2;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_1 = junk_0;
    x = ((x) + (1));
    junk_2 = junk_1;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
