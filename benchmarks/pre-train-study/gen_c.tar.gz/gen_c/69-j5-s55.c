int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 7;
  int junk_2 = 4;
  int junk_3 = 0;
  int junk_4 = 5;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_4 = junk_2 - (junk_4);
    x = ((x) + (1));
    junk_3 = junk_0;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) >= (0));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
