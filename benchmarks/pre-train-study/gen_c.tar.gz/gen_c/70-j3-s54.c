int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 6;
  int junk_2 = 5;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_0 = 270;
    x = ((x) + (1));
    junk_0 = 625;
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
