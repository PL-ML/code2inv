int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 4;
  int junk_1 = 7;
  int junk_2 = 4;
  int junk_3 = 1;
  int junk_4 = 8;
  //skip 
  x = 1;
  
  while(((x) <= (n)))
  {
    //tb 
    y = ((n) - (x));
    junk_0 = 631 - (596);
    x = ((x) + (1));
    junk_4 = 407 + (junk_2);
  }
    //fb 
  if(((n) > (0))) {
    //tb 
    assert ((y) < (n));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
