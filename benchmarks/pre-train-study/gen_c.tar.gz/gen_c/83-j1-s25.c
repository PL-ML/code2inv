int main()
{
  int x;
  int y;
  int junk_0 = 9;
  //skip 
  x = -5000;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = 418;
    y = ((y) + (1));
    junk_0 = 717;
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
