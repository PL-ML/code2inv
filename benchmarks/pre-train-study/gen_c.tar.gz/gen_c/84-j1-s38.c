int main()
{
  int x;
  int y;
  int junk_0 = 2;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = 536 + (junk_0);
    y = ((y) + (1));
    junk_0 = 445 + (junk_0);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
