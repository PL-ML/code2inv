int main()
{
  int x;
  int y;
  int junk_0 = 8;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = 255 + (junk_0);
    y = ((y) + (1));
    junk_0 = junk_0 - (60);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
