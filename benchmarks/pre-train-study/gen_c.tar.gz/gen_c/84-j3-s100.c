int main()
{
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 1;
  int junk_2 = 2;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_2 = junk_2 - (junk_0);
    y = ((y) + (1));
    junk_1 = junk_2 - (0);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
