int main()
{
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 4;
  int junk_2 = 1;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_1 = junk_1 + (298);
    y = ((y) + (1));
    junk_0 = 196;
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
