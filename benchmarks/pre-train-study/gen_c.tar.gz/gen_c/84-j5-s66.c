int main()
{
  int x;
  int y;
  int junk_0 = 4;
  int junk_1 = 8;
  int junk_2 = 0;
  int junk_3 = 4;
  int junk_4 = 9;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_1 = 747 + (620);
    y = ((y) + (1));
    junk_3 = 4 + (556);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
