int main()
{
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 1;
  int junk_2 = 5;
  int junk_3 = 5;
  int junk_4 = 9;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_2 = 810;
    y = ((y) + (1));
    junk_3 = 190;
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
