int main()
{
  int x;
  int y;
  int junk_0 = 4;
  //skip 
  x = -15000;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = junk_0 + (292);
    y = ((y) + (1));
    junk_0 = 932;
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
