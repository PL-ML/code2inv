int main()
{
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 5;
  int junk_2 = 9;
  //skip 
  x = -15000;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_2 = 876 + (798);
    y = ((y) + (1));
    junk_2 = 38 + (junk_0);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
