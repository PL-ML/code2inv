int main()
{
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 4;
  int junk_2 = 4;
  int junk_3 = 9;
  int junk_4 = 2;
  //skip 
  x = -15000;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_3 = 794 - (87);
    y = ((y) + (1));
    junk_4 = junk_2;
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
