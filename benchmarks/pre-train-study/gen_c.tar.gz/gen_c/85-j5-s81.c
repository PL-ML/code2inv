int main()
{
  int x;
  int y;
  int junk_0 = 6;
  int junk_1 = 4;
  int junk_2 = 6;
  int junk_3 = 4;
  int junk_4 = 5;
  //skip 
  x = -15000;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_3 = 665 + (482);
    y = ((y) + (1));
    junk_4 = 818 - (junk_0);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
