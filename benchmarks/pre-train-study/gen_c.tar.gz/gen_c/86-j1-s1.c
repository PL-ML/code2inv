int main()
{
  int x;
  int y;
  int junk_0 = 6;
  //skip 
  x = -50;
  
  while(((x) < (0)))
  {
    //tb 
    x = ((x) + (y));
    junk_0 = junk_0 + (555);
    y = ((y) + (1));
    junk_0 = 259 - (junk_0);
  }
    //fb 
  assert ((y) > (0));
  //skip 


}
