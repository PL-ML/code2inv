int main()
{
  int lock;
  int tmp;
  int x;
  int y;
  int junk_0 = 7;
  //skip 
  x = y;
  
  lock = 1;
  
  while(((x) != (y)))
  {
    //tb 
    if(unknown()) {
      //tb 
      lock = 1;
      junk_0 = junk_0;
      x = y;
      junk_0 = 575 - (junk_0);
    }
    else{
      //fb 
      lock = 0;
      junk_0 = junk_0;
      x = y;
      junk_0 = 244 - (571);
      y = ((y) + (1));
      junk_0 = junk_0 - (783);
    }
  }
    //fb 
  assert ((lock) == (1));
  //skip 


}
