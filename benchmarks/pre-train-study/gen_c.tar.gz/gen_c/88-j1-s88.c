int main()
{
  int lock;
  int tmp;
  int x;
  int y;
  int junk_0 = 5;
  //skip 
  y = ((x) + (1));
  
  lock = 0;
  
  while(((x) != (y)))
  {
    //tb 
    if(unknown()) {
      //tb 
      lock = 1;
      junk_0 = 735;
      x = y;
      junk_0 = junk_0 + (81);
    }
    else{
      //fb 
      lock = 0;
      junk_0 = junk_0 - (554);
      x = y;
      junk_0 = junk_0 - (junk_0);
      y = ((y) + (1));
      junk_0 = junk_0;
    }
  }
    //fb 
  assert ((lock) == (1));
  //skip 


}
