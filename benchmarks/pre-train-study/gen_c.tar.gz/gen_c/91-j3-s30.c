int main()
{
  int x;
  int y;
  int junk_0 = 1;
  int junk_1 = 7;
  int junk_2 = 3;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_1 = 908;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
