int main()
{
  int x;
  int y;
  int junk_0 = 5;
  int junk_1 = 3;
  int junk_2 = 4;
  int junk_3 = 3;
  int junk_4 = 8;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_3 = junk_2 + (917);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
