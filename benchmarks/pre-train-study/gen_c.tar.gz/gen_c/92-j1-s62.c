int main()
{
  int x;
  int y;
  int junk_0 = 8;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_0 = junk_0;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
