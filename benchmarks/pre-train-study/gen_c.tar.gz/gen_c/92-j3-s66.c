int main()
{
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 1;
  int junk_2 = 5;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_1 = junk_0;
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
