int main()
{
  int x;
  int y;
  int junk_0 = 3;
  int junk_1 = 8;
  int junk_2 = 5;
  int junk_3 = 6;
  int junk_4 = 4;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_4 = 579 - (junk_2);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
