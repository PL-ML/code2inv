int main()
{
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 6;
  int junk_2 = 3;
  int junk_3 = 9;
  int junk_4 = 1;
  //skip 
  x = 0;
  
  y = 0;
  
  while(((y) >= (0)))
  {
    //tb 
    y = ((y) + (x));
    junk_1 = junk_2 - (junk_3);
  }
    //fb 
  assert ((y) >= (0));
  //skip 


}
