int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 5;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 1;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0 + (855);
    j = ((j) + (y));
    junk_0 = 472 + (junk_0);
  }
    //fb 
  if(((y) == (1))) {
    //tb 
    assert ((i) == (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
