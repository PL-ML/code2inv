int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 1;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 1;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0 + (827);
    j = ((j) + (y));
    junk_0 = junk_0 - (224);
  }
    //fb 
  if(((i) != (j))) {
    //tb 
    assert ((y) != (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
