int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 0;
  int junk_1 = 7;
  int junk_2 = 1;
  int junk_3 = 7;
  int junk_4 = 1;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 1;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_2 = 589;
    j = ((j) + (y));
    junk_1 = junk_0;
  }
    //fb 
  if(((i) != (j))) {
    //tb 
    assert ((y) != (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
