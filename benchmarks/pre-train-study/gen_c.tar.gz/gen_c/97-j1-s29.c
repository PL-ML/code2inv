int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 1;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 2;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = junk_0;
    j = ((j) + (y));
    junk_0 = 55 - (690);
  }
    //fb 
  if(((y) == (1))) {
    //tb 
    assert ((i) == (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
