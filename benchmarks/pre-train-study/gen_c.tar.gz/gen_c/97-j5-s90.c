int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 0;
  int junk_1 = 4;
  int junk_2 = 7;
  int junk_3 = 3;
  int junk_4 = 8;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 2;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = 298;
    j = ((j) + (y));
    junk_0 = junk_3;
  }
    //fb 
  if(((y) == (1))) {
    //tb 
    assert ((i) == (j));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
