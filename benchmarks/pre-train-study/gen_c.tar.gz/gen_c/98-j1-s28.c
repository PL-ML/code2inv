int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 4;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 2;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_0 = 254;
    j = ((j) + (y));
    junk_0 = junk_0;
  }
    //fb 
  if(((i) != (j))) {
    //tb 
    assert ((y) != (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
