int main()
{
  int i;
  int j;
  int x;
  int y;
  int junk_0 = 2;
  int junk_1 = 1;
  int junk_2 = 7;
  int junk_3 = 3;
  int junk_4 = 4;
  //skip 
  j = 0;
  
  i = 0;
  
  y = 2;
  
  while(((i) <= (x)))
  {
    //tb 
    i = ((i) + (1));
    junk_3 = 105 - (junk_1);
    j = ((j) + (y));
    junk_1 = 966;
  }
    //fb 
  if(((i) != (j))) {
    //tb 
    assert ((y) != (1));
  }
  else{
    //fb 
  }
  //skip 
  //skip 


}
