int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 5;
  //skip 
  assume ((n) >= (0));
  x = n;
  
  y = 0;
  
  while(((x) > (0)))
  {
    //tb 
    y = ((y) + (1));
    junk_0 = 709 - (808);
    x = ((x) - (1));
    junk_0 = 606;
  }
    //fb 
  assert ((n) == (((x) + (y))));
  //skip 


}
