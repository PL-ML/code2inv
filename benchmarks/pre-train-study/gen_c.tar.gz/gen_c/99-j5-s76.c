int main()
{
  int n;
  int x;
  int y;
  int junk_0 = 9;
  int junk_1 = 6;
  int junk_2 = 9;
  int junk_3 = 1;
  int junk_4 = 7;
  //skip 
  assume ((n) >= (0));
  x = n;
  
  y = 0;
  
  while(((x) > (0)))
  {
    //tb 
    y = ((y) + (1));
    junk_0 = 0 - (479);
    x = ((x) - (1));
    junk_2 = 619 - (708);
  }
    //fb 
  assert ((n) == (((x) + (y))));
  //skip 


}
